npm run start Runs the server code once using Node.

npm run server Runs the server continuously using the nodemon package. The server will automatically restart when you change a file in the server code.
